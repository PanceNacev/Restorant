﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Restorant.ViewModel
{
    public class KlientViewModel
    {
        public int KlientId { get; set; }
        public string KlientIme { get; set; }
    }
}