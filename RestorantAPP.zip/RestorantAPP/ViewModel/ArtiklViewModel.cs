﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Restorant.ViewModel
{
    public class ArtiklViewModel
    {
        public int ArtiklId { get; set; }
        public string ArtiklIme { get; set; }
        public decimal Cena { get; set; }
    }
}