﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Restorant.ViewModel
{
    public class TipNaNaplataViewModel
    {
        public string TipNaNaplataIme { get; set; }
        public int TipNaNaplataId { get; set; }
    }
}